<?php
// Copy this file to config.php and edit with your DB credentials
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'idc_alliance',
    'db_user' => 'root',
    'db_pass' => '',
    'admin_user' => 'admin',
    'admin_pass' => '123456', // installer will hash; used only for initial setup
    'base_url' => '/', // adjust to your server root, e.g. '/idc_alliance/'
];
