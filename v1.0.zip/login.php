<?php
require 'lib/db.php';
require 'lib/auth.php';
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (login_user_by_name($_POST['username'] ?? '', $_POST['password'] ?? '')) {
        header('Location: /');
        exit;
    } else { $error = '登录失败，用户名或密码错误'; }
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IDC 联盟 - 登录</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #16a085;
            --light-bg: #f8f9fa;
            --dark-bg: #1a2530;
        }
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-custom {
            background: var(--dark-bg);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 0.8rem 1rem;
        }
        .navbar-brand {
            font-weight: 700;
            color: white !important;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
        }
        .navbar-brand i {
            margin-right: 10px;
            color: var(--secondary-color);
        }
        .login-card {
            max-width: 400px;
            margin: 80px auto;
            padding: 2.5rem;
            border-radius: 15px;
            background: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .login-card h2 {
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--primary-color);
            text-align: center;
        }
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        .btn-login {
            background: var(--secondary-color);
            border: none;
            font-weight: 600;
        }
        .btn-login:hover {
            background: #2980b9;
        }
        .captcha-img {
            cursor: pointer;
            border-radius: 8px;
            margin-top: 5px;
        }
        .error {
            margin-bottom: 15px;
            color: #dc3545;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-hdd-network-fill"></i>IDC 联盟
            </a>
        </div>
    </nav>

    <main class="container">
        <div class="login-card">
            <h2>用户登录</h2>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
            <?php endif; ?>
            <form method="post">
                <div class="mb-3">
                    <label for="username" class="form-label">用户名</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">密码</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">图形验证码</label>
                    <div class="d-flex align-items-center">
                        <input type="text" class="form-control me-2" name="captcha" placeholder="输入验证码" required>
                        <img src="captcha.php" alt="captcha" class="captcha-img" onclick="this.src='captcha.php?'+Math.random()" title="点击刷新验证码">
                    </div>
                </div>
                <button type="submit" class="btn btn-login w-100"><i class="bi bi-box-arrow-in-right"></i> 登录</button>
            </form>
            <p class="mt-3 text-center text-muted">没有账号？ <a href="/register.php">注册</a></p>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>