<?php
require 'lib/db.php';
require 'lib/auth.php';
$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: /'); exit; }
$pdo = get_db();
$stmt = $pdo->prepare('SELECT * FROM idcs WHERE id=? LIMIT 1');
$stmt->execute([$id]);
$idc = $stmt->fetch();
if (!$idc) { echo '找不到此 IDC'; exit; }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = trim($_POST['name'] ?? '匿名');
    $content = trim($_POST['content'] ?? '');
    if ($content!=='') {
        $ins = $pdo->prepare('INSERT INTO comments (idc_id,user_name,content) VALUES (?,?,?)');
        $ins->execute([$id, $name, $content]);
        header('Location: /comments.php?id='.$id);
        exit;
    }
}
$cstmt = $pdo->prepare('SELECT * FROM comments WHERE idc_id=? AND is_hidden=0 ORDER BY created_at DESC');
$cstmt->execute([$id]);
$comments = $cstmt->fetchAll();
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>评价 - <?=htmlspecialchars($idc['name'])?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --accent-color: #16a085;
    --light-bg: #f8f9fa;
    --dark-bg: #1a2530;
}
body {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.navbar-custom {
    background: var(--dark-bg);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    padding: 0.8rem 1rem;
}
.navbar-brand {
    font-weight: 700;
    color: white !important;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
}
.navbar-brand i {
    margin-right: 10px;
    color: var(--secondary-color);
}
.container-main {
    max-width: 800px;
    margin: 40px auto;
}
.idc-card {
    display: flex;
    align-items: center;
    background: white;
    padding: 1.5rem;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    margin-bottom: 2rem;
}
.idc-card img.logo {
    max-width: 100px;
    margin-right: 20px;
    border-radius: 12px;
}
.comments form {
    display: flex;
    flex-direction: column;
    margin-bottom: 2rem;
    background: white;
    padding: 1.5rem;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}
.comments form input, .comments form textarea {
    margin-bottom: 1rem;
    border-radius: 8px;
    border: 1px solid #ced4da;
    padding: 0.7rem;
}
.comments form button {
    background: var(--secondary-color);
    color: white;
    border: none;
    border-radius: 50px;
    padding: 0.6rem 1.5rem;
    font-weight: 600;
}
.comments form button:hover {
    background: #2980b9;
}
.comment-card {
    background: #f8f9fa;
    padding: 1rem;
    border-radius: 12px;
    margin-bottom: 1rem;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}
.comment-card strong {
    color: var(--primary-color);
}
.comment-card small {
    color: gray;
    float: right;
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container">
        <a class="navbar-brand" href="/"><i class="bi bi-hdd-network-fill"></i> IDC 联盟</a>
    </div>
</nav>

<main class="container container-main">
    <div class="idc-card">
        <img class="logo" src="<?=htmlspecialchars($idc['logo']?:'assets/logos/sample_logo.png')?>" alt="logo">
        <div>
            <h2><?=htmlspecialchars($idc['name'])?></h2>
            <p>ID: <?=htmlspecialchars($idc['uid'])?></p>
        </div>
    </div>

    <section class="comments">
        <h3>评论区</h3>
        <form method="post">
            <input name="name" placeholder="你的昵称 (可选)">
            <textarea name="content" placeholder="写下你的评价..." required></textarea>
            <button type="submit"><i class="bi bi-chat-dots-fill"></i> 提交评价</button>
        </form>

        <?php if (empty($comments)): ?>
            <p>还没有评论。成为第一位！</p>
        <?php else: foreach($comments as $c): ?>
            <div class="comment-card">
                <strong><?=htmlspecialchars($c['user_name'])?></strong>
                <small><?=htmlspecialchars($c['created_at'])?></small>
                <p><?=nl2br(htmlspecialchars($c['content']))?></p>
            </div>
        <?php endforeach; endif; ?>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>