<?php
session_start();
$code = substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZ23456789'),0,4);
$_SESSION['captcha'] = $code;
header('Content-Type: image/png');
$im = imagecreatetruecolor(120,40);
$bg = imagecolorallocate($im, 240,240,240);
imagefilledrectangle($im,0,0,120,40,$bg);
$textc = imagecolorallocate($im,20,50,100);
imagestring($im,5,10,10,$code,$textc);
for($i=0;$i<80;$i++){ imagesetpixel($im, rand(0,119), rand(0,39), imagecolorallocate($im, rand(100,200), rand(100,200), rand(100,200))); }
imagepng($im);
imagedestroy($im);
