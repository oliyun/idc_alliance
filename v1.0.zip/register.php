<?php
require 'lib/db.php';
require 'lib/auth.php';
$pdo = get_db();
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $uid = trim($_POST['uid'] ?? '');
    $logo = 'assets/logos/sample_logo.png';
    if (empty($username) || empty($password)) { $error = '用户名和密码必填'; }
    else {
        $upload_path = __DIR__.'/uploads/logos/';
        if (!is_dir($upload_path)) mkdir($upload_path,0777,true);
        if (!empty($_FILES['logo']['name'])) {
            $allowed = ['image/png'=>'png','image/jpeg'=>'jpg','image/gif'=>'gif'];
            if (isset($allowed[$_FILES['logo']['type']])) {
                $ext = $allowed[$_FILES['logo']['type']];
                $newName = uniqid('logo_').'.'.$ext;
                $dest = $upload_path.$newName;
                move_uploaded_file($_FILES['logo']['tmp_name'],$dest);
                $logo = 'uploads/logos/'.$newName;
            }
        }

        $h = password_hash($password, PASSWORD_DEFAULT);
        try {
            $ins = $pdo->prepare('INSERT INTO users (username,password) VALUES (?,?)');
            $ins->execute([$username,$h]);
            if ($uid) {
                $stmt = $pdo->prepare('INSERT INTO idcs (uid,name,website,contact,logo) VALUES (?,?,?,?,?)');
                $stmt->execute([$uid,$_POST['name'] ?? $username,$_POST['website'] ?? '',$_POST['contact'] ?? '', $logo]);
            }
            header('Location: /login.php');
            exit;
        } catch (Exception $e) {
            $error = '注册失败: '.$e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IDC 联盟 - 注册</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --accent-color: #16a085;
    --light-bg: #f8f9fa;
    --dark-bg: #1a2530;
}
body {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.navbar-custom {
    background: var(--dark-bg);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    padding: 0.8rem 1rem;
}
.navbar-brand {
    font-weight: 700;
    color: white !important;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
}
.navbar-brand i {
    margin-right: 10px;
    color: var(--secondary-color);
}
.register-card {
    max-width: 500px;
    margin: 80px auto;
    padding: 2.5rem;
    border-radius: 15px;
    background: white;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}
.register-card h2 {
    font-weight: 700;
    margin-bottom: 1.5rem;
    color: var(--primary-color);
    text-align: center;
}
.form-control:focus {
    border-color: var(--secondary-color);
    box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
}
.btn-register {
    background: var(--secondary-color);
    border: none;
    font-weight: 600;
}
.btn-register:hover { background: #2980b9; }
.error {
    margin-bottom: 15px;
    color: #dc3545;
    font-weight: 500;
}
#logoPreview {
    max-width:150px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container">
        <a class="navbar-brand" href="/">
            <i class="bi bi-hdd-network-fill"></i>IDC 联盟
        </a>
    </div>
</nav>

<main class="container">
    <div class="register-card">
        <h2>用户注册</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
        <?php endif; ?>
        <form method="post" enctype="multipart/form-data" class="needs-validation">
            <div class="mb-3">
                <label class="form-label">账户名</label>
                <input name="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">密码</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">IDC 独立识别码 (UID，可选)</label>
                <input name="uid" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">名称(可选)</label>
                <input name="name" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">官网(可选)</label>
                <input name="website" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">联系方式(可选)</label>
                <input name="contact" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">Logo 上传</label>
                <input type="file" name="logo" class="form-control" accept="image/*" onchange="previewLogo(event)">
                <div class="mt-2 text-center">
                    <img id="logoPreview" src="assets/logos/sample_logo.png" alt="Logo 预览">
                </div>
            </div>
            <button type="submit" class="btn btn-register w-100"><i class="bi bi-person-plus-fill"></i> 注册</button>
        </form>
        <p class="mt-3 text-center text-muted">已有账号？ <a href="/login.php">登录</a></p>
    </div>
</main>

<script>
function previewLogo(event) {
    const output = document.getElementById('logoPreview');
    const file = event.target.files[0];
    if(file) {
        const reader = new FileReader();
        reader.onload = function(e) { output.src = e.target.result; }
        reader.readAsDataURL(file);
    } else {
        output.src = 'assets/logos/sample_logo.png';
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>