<?php
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'idc_alliance',
    'db_user' => 'idc_alliance',
    'db_pass' => 'navr',
    'admin_user' => 'admin',
    'admin_pass' => '123456',
    'base_url' => '/',
];