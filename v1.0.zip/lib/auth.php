<?php
session_start();
require_once __DIR__.'/db.php';

function is_logged_in(){
    return !empty($_SESSION['user']);
}
function current_user(){
    return $_SESSION['user'] ?? null;
}
function require_admin(){
    if (!is_logged_in() || current_user()['role']!=='admin') {
        header('Location: /login.php');
        exit;
    }
}
function login_user_by_name($username, $password){
    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username=? LIMIT 1');
    $stmt->execute([$username]);
    $u = $stmt->fetch();
    if (!$u) return false;
    if (password_verify($password, $u['password'])) {
        unset($u['password']);
        $_SESSION['user'] = $u;
        return true;
    }
    return false;
}
