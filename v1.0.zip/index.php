<?php
require 'lib/db.php';
require 'lib/auth.php';
$base = (require 'config.php')['base_url'] ?? '/';
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IDC 联盟 - 首页</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #16a085;
            --light-bg: #f8f9fa;
            --dark-bg: #1a2530;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-custom {
            background: var(--dark-bg);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 0.8rem 1rem;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: white !important;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
        }
        
        .navbar-brand i {
            margin-right: 10px;
            color: var(--secondary-color);
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            margin: 0 0.2rem;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: white !important;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .nav-link.active {
            background: var(--secondary-color);
            color: white !important;
        }
        
        .welcome-text {
            color: #eee;
            padding: 0.5rem 0;
            margin-right: 1rem;
        }
        
        .hero-section {
            background: linear-gradient(120deg, var(--primary-color), var(--dark-bg));
            color: white;
            padding: 4rem 0;
            margin-bottom: 3rem;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        .hero-title {
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 1.5rem;
        }
        
        .hero-subtitle {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        
        .search-box {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-top: -40px;
            position: relative;
            z-index: 10;
        }
        
        .search-input {
            padding: 1.2rem 1.5rem;
            border-radius: 50px;
            border: 2px solid #e2e8f0;
            font-size: 1.1rem;
            transition: all 0.3s;
        }
        
        .search-input:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .search-btn {
            padding: 0.8rem 2rem;
            border-radius: 50px;
            background: var(--secondary-color);
            border: none;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s;
        }
        
        .search-btn:hover {
            background: #2980b9;
            transform: translateY(-2px);
        }
        
        .features-section {
            padding: 4rem 0;
        }
        
        .feature-card {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            height: 100%;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            border: none;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.12);
        }
        
        .feature-icon {
            font-size: 2.5rem;
            color: var(--secondary-color);
            margin-bottom: 1.5rem;
        }
        
        .feature-title {
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
        
        .footer {
            background: var(--dark-bg);
            color: white;
            padding: 3rem 0;
            margin-top: 4rem;
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.2rem;
            }
            
            .hero-subtitle {
                font-size: 1.1rem;
            }
            
            .search-box {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-hdd-network-fill"></i>IDC 联盟
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="/">首页</a>
                    </li>
                    <?php if(!is_logged_in()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/register.php">注册</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/login.php">登录</a>
                    </li>
                    <?php else: ?>
                    <li class="nav-item">
                        <span class="welcome-text">欢迎，<?=htmlspecialchars(current_user()['username'])?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/logout.php">退出</a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                >
            </div>
        </div>
    </nav>

    <div class="hero-section">
        <div class="container text-center">
            <h1 class="hero-title">IDC 联盟 — 全网 IDC 聚合平台</h1>
            <p class="hero-subtitle">为您提供最全面、最专业的IDC服务商信息与资源整合</p>
        </div>
    </div>

    <div class="container">
        <div class="search-box">
            <form action="search.php" method="get" class="row g-3 align-items-center">
                <div class="col-md-9">
                    <input type="text" name="q" class="form-control search-input" placeholder="输入关键词或IDC（例如 IDC-0001）" required>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100 search-btn">
                        <i class="bi bi-search"></i> 搜索 IDC
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="container features-section">
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="feature-card text-center">
                    <div class="feature-icon">
                        <i class="bi bi-database-fill"></i>
                    </div>
                    <h3 class="feature-title">IDC资源库</h3>
                    <p>收录全网优质IDC服务商信息，提供详细参数、价格对比和用户评价，帮助您快速找到最适合的服务商。</p>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="feature-card text-center">
                    <div class="feature-icon">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <h3 class="feature-title">社区交流</h3>
                    <p>加入IDC行业社区，与技术专家和行业同仁交流经验，分享最佳实践，解决技术难题。</p>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="feature-card text-center">
                    <div class="feature-icon">
                        <i class="bi bi-graph-up-arrow"></i>
                    </div>
                    <h3 class="feature-title">市场分析</h3>
                    <p>获取IDC行业最新市场动态、趋势分析和数据报告，为您的决策提供有力支持。</p>
                </div>
            </div>
        </div>
        
        <section class="mt-5 p-4 bg-white rounded-3 shadow-sm">
            <h2 class="mb-4">示例操作</h2>
            <p>您可以注册一个账号并登记/修改您的IDC信息（需登录）。</p>
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <?php if(!is_logged_in()): ?>
                <a class="btn btn-primary me-md-2" href="/register.php">
                    <i class="bi bi-person-plus-fill"></i> 立即注册
                </a>
                <a class="btn btn-outline-secondary" href="/login.php">
                    <i class="bi bi-box-arrow-in-right"></i> 登录账户
                </a>
                <?php else: ?>
                <a class="btn btn-success" href="/admin">
                    <i class="bi bi-pencil-square"></i> 管理IDC信息
                </a>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>IDC 联盟</h5>
                    <p>致力于为您提供最全面、最专业的IDC服务商信息与资源整合平台。</p>
                </div>
                <div class="col-md-3">
                    <h5>快速链接</h5>
                    <ul class="list-unstyled">
                        <li><a href="/" class="text-light">首页</a></li>
                        <li><a href="#" class="text-light">关于我们</a></li>
                        <li><a href="#" class="text-light">服务条款</a></li>
                        <li><a href="#" class="text-light">隐私政策</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>联系我们</h5>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-envelope me-2"></i> contact@idc-alliance.com</li>
                        <li><i class="bi bi-telephone me-2"></i> 400-123-4567</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="text-center">
                <p>© 2023 IDC联盟. 保留所有权利.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
