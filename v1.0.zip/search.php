<?php
require 'lib/db.php';
require 'lib/auth.php';
$q = trim($_GET['q'] ?? '');
$pdo = get_db();
if ($q === '') {
    header('Location: /');
    exit;
}
$stmt = $pdo->prepare("SELECT * FROM idcs WHERE uid LIKE ? OR name LIKE ? LIMIT 50");
$like = "%".$q."%";
$stmt->execute([$like, $like]);
$rows = $stmt->fetchAll();
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>搜索：<?=htmlspecialchars($q)?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --accent-color: #16a085;
    --light-bg: #f8f9fa;
    --dark-bg: #1a2530;
}
body {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.navbar-custom {
    background: var(--dark-bg);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    padding: 0.8rem 1rem;
}
.navbar-brand {
    font-weight: 700;
    color: white !important;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
}
.navbar-brand i {
    margin-right: 10px;
    color: var(--secondary-color);
}
.container h1 {
    color: var(--primary-color);
    margin-top: 2rem;
    margin-bottom: 2rem;
    text-align: center;
}
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.5rem;
}
.card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    overflow: hidden;
    transition: transform 0.3s, box-shadow 0.3s;
}
.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.15);
}
.card img.logo {
    width: 100%;
    height: 150px;
    object-fit: contain;
    background: #f8f9fa;
}
.card-body {
    padding: 1.5rem;
}
.card-body h3 {
    margin-bottom: 0.5rem;
    color: var(--primary-color);
}
.card-body p {
    margin-bottom: 0.5rem;
}
.card-actions {
    margin-top: 1rem;
    display: flex;
    gap: 0.5rem;
}
.card-actions .btn {
    flex: 1;
    border-radius: 50px;
    font-weight: 500;
    transition: all 0.3s;
}
.card-actions .btn:hover {
    transform: translateY(-2px);
}
.btn-home {
    background: var(--secondary-color);
    color: white;
    border: none;
}
.btn-home:hover { background: #2980b9; }
.btn-comment {
    background: var(--accent-color);
    color: white;
    border: none;
}
.btn-comment:hover { background: #139876; }
.nav {
    display: flex;
    justify-content: space-between;
    background: var(--dark-bg);
    padding: 0.8rem 1rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.nav a {
    color: white;
    font-weight: 500;
    text-decoration: none;
    padding: 0.3rem 0.6rem;
    border-radius: 4px;
    transition: all 0.3s;
}
.nav a:hover { background: rgba(255,255,255,0.1); }
.nav a.right { margin-left: auto; }
</style>
</head>
<body>
<nav class="nav">
    <a href="/" class="nav-item"><i class="bi bi-house-fill"></i> 首页</a>
</nav>

<main class="container">
    <h1>搜索结果 for <?=htmlspecialchars($q)?></h1>
    <?php if (empty($rows)): ?>
        <p class="text-center">没有找到匹配的 IDC。</p>
        <div class="text-center"><a href="/" class="btn btn-home mt-2"><i class="bi bi-arrow-left"></i> 返回首页</a></div>
    <?php else: ?>
        <div class="cards">
        <?php foreach($rows as $r): ?>
            <div class="card">
                <img class="logo" src="<?=htmlspecialchars($r['logo']?:'assets/logos/sample_logo.png')?>" alt="logo">
                <div class="card-body">
                    <h3><?=htmlspecialchars($r['name'])?></h3>
                    <p>官网: <a href="<?=htmlspecialchars($r['website'])?>" target="_blank"><?=htmlspecialchars($r['website'])?></a></p>
                    <p>联系方式: <?=htmlspecialchars($r['contact'])?></p>
                    <p>认证: <strong><?=htmlspecialchars($r['auth_status'])?></strong></p>
                    <p>ID: <?=htmlspecialchars($r['uid'])?> • 登记: <?=htmlspecialchars($r['created_at'])?></p>
                    <div class="card-actions">
                        <a class="btn btn-home" href="/"><i class="bi bi-house-fill"></i> 返回首页</a>
                        <a class="btn btn-comment" href="/comments.php?id=<?=intval($r['id'])?>"><i class="bi bi-chat-dots-fill"></i> 评价</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>