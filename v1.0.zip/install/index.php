<?php
// Simple visual installer. Place this folder in web root and visit /install/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_POST['db_host']; $name = $_POST['db_name']; $user = $_POST['db_user']; $pass = $_POST['db_pass'];
    $admin_user = $_POST['admin_user'] ?: 'admin';
    $admin_pass = $_POST['admin_pass'] ?: '123456';
    // create config.php
    $cfg = <<<PHP
<?php
return [
    'db_host' => '$host',
    'db_name' => '$name',
    'db_user' => '$user',
    'db_pass' => '$pass',
    'admin_user' => '$admin_user',
    'admin_pass' => '$admin_pass',
    'base_url' => '/',
];
PHP;
    file_put_contents(__DIR__.'/../config.php', $cfg);
    // run SQL
    $sql = file_get_contents(__DIR__.'/schema.sql');
    $hash = password_hash($admin_pass, PASSWORD_DEFAULT);
    $sql = str_replace('[[ADMIN_PWD_HASH]]', $hash, $sql);
    try {
        $pdo = new PDO("mysql:host=$host;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        $pdo->exec($sql);

        $installDir = __DIR__;
        $newDir = $installDir.'_bak_'.date('Ymd_His');
        rename($installDir,$newDir);
        echo "<h2>安装成功</h2><p>请删除 install 目录：/install</p><p><a href='/'>前往首页</a></p>";
        exit;
    } catch (Exception $e) {
        echo '<h2>安装失败</h2><pre>'.htmlspecialchars($e->getMessage()).'</pre>';
    }
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>安装 - IDC 联盟</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');
    * { box-sizing: border-box; margin:0; padding:0; font-family: 'Inter', sans-serif; }
    body { background: #f0f2f5; display: flex; justify-content: center; align-items: center; height: 100vh; }
    main { background: #fff; padding: 40px; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
    h1 { text-align: center; margin-bottom: 30px; color: #333; }
    form { display: flex; flex-direction: column; gap: 15px; }
    label { display: flex; flex-direction: column; font-weight: 600; color: #555; }
    input { padding: 10px 15px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px; transition: border-color 0.3s; }
    input:focus { border-color: #4f7df3; outline: none; box-shadow: 0 0 5px rgba(79,125,243,0.3); }
    button { padding: 12px; background: #4f7df3; color: #fff; border: none; border-radius: 5px; font-weight: 600; cursor: pointer; transition: background 0.3s; }
    button:hover { background: #3b63d6; }
    p.success, p.error { text-align: center; margin-top: 20px; font-weight: 600; }
    a { color: #4f7df3; text-decoration: none; }
    a:hover { text-decoration: underline; }
</style>
</head>
<body>
<main>
  <h1>安装向导</h1>
  <form method="post">
    <label>数据库主机
      <input name="db_host" value="127.0.0.1">
    </label>
    <label>数据库名
      <input name="db_name" value="idc_alliance">
    </label>
    <label>数据库用户
      <input name="db_user" value="root">
    </label>
    <label>数据库密码
      <input type="password" name="db_pass" value="">
    </label>
    <label>后台用户名
      <input name="admin_user" value="admin">
    </label>
    <label>后台密码
      <input type="password" name="admin_pass" value="123456">
    </label>
    <button type="submit">开始安装</button>
  </form>
</main>
</body>
</html>