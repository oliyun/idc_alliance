-- IDC Alliance schema for MySQL 5.6
CREATE DATABASE IF NOT EXISTS idc_alliance DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE idc_alliance;

-- users table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- idcs table (records)
CREATE TABLE IF NOT EXISTS idcs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uid VARCHAR(64) NOT NULL UNIQUE, -- unique IDC identifier
  name VARCHAR(255) NOT NULL,
  company VARCHAR(255),
  website VARCHAR(255),
  contact VARCHAR(255),
  auth_status ENUM('unverified','verified','suspended') DEFAULT 'unverified',
  logo VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- comments
CREATE TABLE IF NOT EXISTS comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  idc_id INT NOT NULL,
  user_name VARCHAR(100),
  content TEXT,
  is_hidden TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (idc_id) REFERENCES idcs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- blacklist
CREATE TABLE IF NOT EXISTS blacklist (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type ENUM('contact','domain','uid') NOT NULL,
  value VARCHAR(255) NOT NULL,
  note VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- sample admin user (password: admin123 -> hashed by installer if used)
INSERT INTO users (username, password, role) VALUES ('admin', '[[ADMIN_PWD_HASH]]', 'admin');

-- sample idc entry
INSERT INTO idcs (uid, name, company, website, contact, auth_status, logo) VALUES
('IDC-0001','示例IDC','示例公司','https://example-idc.com','wechat:example','verified','assets/logos/sample_logo.png');