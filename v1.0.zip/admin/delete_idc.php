<?php
require '../lib/db.php';
require '../lib/auth.php';
require_admin();
$id = intval($_GET['id'] ?? 0);
if ($id) {
    $pdo = get_db();
    $pdo->prepare('DELETE FROM idcs WHERE id=?')->execute([$id]);
}
header('Location: /admin');
