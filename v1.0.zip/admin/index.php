<?php
require '../lib/db.php';
require '../lib/auth.php';
require_admin();
$pdo = get_db();
$idcs = $pdo->query('SELECT * FROM idcs ORDER BY created_at DESC')->fetchAll();
$comments = $pdo->query('SELECT * FROM comments ORDER BY created_at DESC LIMIT 10')->fetchAll();
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>后台管理 - IDC 联盟</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --accent-color: #16a085;
    --danger-color: #e74c3c;
    --light-bg: #f8f9fa;
    --dark-bg: #1a2530;
}
body {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.navbar-custom {
    background: var(--dark-bg);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    padding: 0.8rem 1rem;
}
.navbar-brand {
    font-weight: 700;
    color: white !important;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
}
.navbar-brand i {
    margin-right: 10px;
    color: var(--secondary-color);
}
.nav-link {
    color: rgba(255,255,255,0.85);
    margin-left: 1rem;
    transition: all 0.3s;
}
.nav-link:hover { color: white; }
.container-main {
    max-width: 1200px;
    margin: 40px auto;
}
.card-section {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    margin-bottom: 2rem;
}
h1, h2 {
    color: var(--primary-color);
    font-weight: 700;
}
.table th {
    background: var(--secondary-color);
    color: white;
}
.table tbody tr:hover {
    background: rgba(52, 152, 219, 0.1);
}
.btn-edit {
    background: var(--secondary-color);
    color: white;
    border-radius: 50px;
    padding: 0.3rem 0.8rem;
    font-size: 0.9rem;
    margin-right: 0.3rem;
}
.btn-edit:hover { background: #2980b9; }
.btn-delete {
    background: var(--danger-color);
    color: white;
    border-radius: 50px;
    padding: 0.3rem 0.8rem;
    font-size: 0.9rem;
}
.btn-delete:hover { background: #c0392b; }
.comment-card {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 0.8rem;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}
.comment-header {
    font-weight: 600;
    color: var(--primary-color);
}
.comment-time {
    font-size: 0.85rem;
    color: gray;
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container">
        <a class="navbar-brand" href="/"><i class="bi bi-hdd-network-fill"></i>IDC 联盟</a>
        <div class="d-flex">
            <a class="nav-link" href="/">前台</a>
            <a class="nav-link" href="/logout.php"><i class="bi bi-box-arrow-right"></i> 退出</a>
        </div>
    </div>
</nav>

<main class="container container-main">
    <h1>后台管理</h1>

    <!-- IDC 列表 -->
    <section class="card-section">
        <h2><i class="bi bi-server"></i> IDC 列表</h2>
        <div class="table-responsive">
        <table class="table table-striped table-hover align-middle">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>UID</th>
                    <th>名称</th>
                    <th>认证</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($idcs as $r): ?>
                <tr>
                    <td><?=$r['id']?></td>
                    <td><?=htmlspecialchars($r['uid'])?></td>
                    <td><?=htmlspecialchars($r['name'])?></td>
                    <td><?=$r['auth_status']?></td>
                    <td>
                        <a class="btn btn-edit" href="edit_idc.php?id=<?=$r['id']?>"><i class="bi bi-pencil-fill"></i> 编辑</a>
                        <a class="btn btn-delete" href="delete_idc.php?id=<?=$r['id']?>" onclick="return confirm('确认删除?')"><i class="bi bi-trash-fill"></i> 删除</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </section>

    <!-- 最新评论 -->
    <section class="card-section">
        <h2><i class="bi bi-chat-dots-fill"></i> 最新评论</h2>
        <?php if(empty($comments)): ?>
            <p>暂无评论</p>
        <?php else: ?>
            <?php foreach($comments as $c): ?>
                <div class="comment-card">
                    <div class="comment-header"><?=htmlspecialchars($c['user_name'])?></div>
                    <div class="comment-time">ID:<?=$c['idc_id']?> — <?=htmlspecialchars($c['created_at'])?></div>
                    <p><?=htmlspecialchars($c['content'])?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>