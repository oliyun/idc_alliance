<?php
require '../lib/db.php';
require '../lib/auth.php';
require_admin();
$pdo = get_db();
$id = intval($_GET['id']??0);
if (!$id) { header('Location: /admin'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $stmt = $pdo->prepare('UPDATE idcs SET name=?,company=?,website=?,contact=?,auth_status=? WHERE id=?');
    $stmt->execute([$_POST['name'],$_POST['company'],$_POST['website'],$_POST['contact'],$_POST['auth_status'], $id]);
    header('Location: /admin'); exit;
}
$r = $pdo->prepare('SELECT * FROM idcs WHERE id=? LIMIT 1'); 
$r->execute([$id]); 
$row = $r->fetch();
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>编辑 IDC - 后台管理</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<style>
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --accent-color: #16a085;
    --danger-color: #e74c3c;
    --light-bg: #f8f9fa;
    --dark-bg: #1a2530;
}
body {
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
.navbar-custom {
    background: var(--dark-bg);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    padding: 0.8rem 1rem;
}
.navbar-brand {
    font-weight: 700;
    color: white !important;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
}
.navbar-brand i {
    margin-right: 10px;
    color: var(--secondary-color);
}
.container-main {
    max-width: 600px;
    margin: 60px auto;
}
.card-form {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}
.card-form h2 {
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 1.5rem;
    text-align: center;
}
.form-control:focus {
    border-color: var(--secondary-color);
    box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
}
.btn-save {
    background: var(--secondary-color);
    color: white;
    border: none;
    font-weight: 600;
    width: 100%;
}
.btn-save:hover { background: #2980b9; }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container">
        <a class="navbar-brand" href="/admin"><i class="bi bi-hdd-network-fill"></i>IDC 后台</a>
        <div class="d-flex">
            <a class="nav-link" href="/admin"><i class="bi bi-house-fill"></i> 后台首页</a>
        </div>
    </div>
</nav>

<main class="container container-main">
    <div class="card-form">
        <h2>编辑 IDC</h2>
        <form method="post">
            <div class="mb-3">
                <label class="form-label">名称</label>
                <input name="name" class="form-control" value="<?=htmlspecialchars($row['name'])?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">公司</label>
                <input name="company" class="form-control" value="<?=htmlspecialchars($row['company'])?>">
            </div>
            <div class="mb-3">
                <label class="form-label">官网</label>
                <input name="website" class="form-control" value="<?=htmlspecialchars($row['website'])?>">
            </div>
            <div class="mb-3">
                <label class="form-label">联系方式</label>
                <input name="contact" class="form-control" value="<?=htmlspecialchars($row['contact'])?>">
            </div>
            <div class="mb-3">
                <label class="form-label">认证状态</label>
                <select name="auth_status" class="form-select">
                    <option <?=$row['auth_status']=='unverified'?'selected':''?> value="unverified">未认证</option>
                    <option <?=$row['auth_status']=='verified'?'selected':''?> value="verified">已认证</option>
                    <option <?=$row['auth_status']=='suspended'?'selected':''?> value="suspended">已封禁</option>
                </select>
            </div>
            <button type="submit" class="btn btn-save"><i class="bi bi-check-lg"></i> 保存</button>
        </form>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>